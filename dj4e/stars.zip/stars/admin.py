from django.contrib import admin

from stars.models import Star, Type

# Register your models here.

admin.site.register(Star)
admin.site.register(Type)

